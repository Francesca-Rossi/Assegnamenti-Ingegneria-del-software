package utils;

public enum Type {
    ADMIN,
    SOCIO,
}
