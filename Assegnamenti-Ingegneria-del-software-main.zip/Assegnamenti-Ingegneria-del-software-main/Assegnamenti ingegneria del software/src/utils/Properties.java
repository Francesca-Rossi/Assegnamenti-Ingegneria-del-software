package utils;

public enum Properties {
    NAME,
    SURNAME,
    EMAIL,
    PASSWORD
}
