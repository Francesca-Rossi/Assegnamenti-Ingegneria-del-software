package entities;

import entities.Activity;

public class Race extends Activity
{
    public Race(){
        super();
    }

    @Override
    public String toString() {
        return "Descrizione Gara";
    }
}
