package entities;

public abstract class Activity {
    public Activity(){ }
}
